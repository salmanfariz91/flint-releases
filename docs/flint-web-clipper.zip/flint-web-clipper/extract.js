/**
 * Runs inside the web page being clipped (the popup injects it) and returns what
 * Flint needs: the title, the main part of the page as HTML, the selected part
 * if something is selected, and a few facts about the page.
 *
 * It must stand alone: Chrome copies only this one function into the page, so it
 * cannot use anything defined outside itself.
 */
function flintExtractPage() {
  var MAX_HTML = 1500000;

  var meta = function (selector) {
    var el = document.querySelector(selector);
    return el ? (el.getAttribute('content') || '').trim() : '';
  };

  // Addresses in the copy are made complete, so links and pictures still work outside the page.
  var fixAddresses = function (root) {
    root.querySelectorAll('a[href]').forEach(function (a) {
      var href = a.getAttribute('href') || '';
      if (/^\s*javascript:/i.test(href)) return a.removeAttribute('href');
      try {
        a.setAttribute('href', new URL(href, location.href).href);
      } catch (e) {
        a.removeAttribute('href');
      }
    });
    root.querySelectorAll('img').forEach(function (img) {
      var src = img.getAttribute('src') || img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || '';
      img.removeAttribute('srcset');
      try {
        img.setAttribute('src', new URL(src, location.href).href);
      } catch (e) {
        img.removeAttribute('src');
      }
    });
  };

  // Things that are not part of the text: scripts, forms, menus, side columns, hidden parts.
  var JUNK =
    'script,style,noscript,template,iframe,object,embed,form,button,input,select,textarea,svg,canvas,dialog,' +
    'nav,aside,footer,[hidden],[aria-hidden="true"],[role="navigation"],[role="complementary"],[role="banner"],' +
    '[role="contentinfo"],[role="search"],.advertisement,.ad-container,.adsbygoogle,.social-share,.share-buttons,' +
    '.related-posts,.newsletter-signup,.cookie-banner,#comments,.comments,.mw-editsection,.noprint,sup.reference,.navbox,.mw-jump-link';

  var cleanCopy = function (el) {
    var copy = el.cloneNode(true);
    copy.querySelectorAll(JUNK).forEach(function (junk) {
      junk.remove();
    });
    fixAddresses(copy);
    return copy;
  };

  var wordsIn = function (el) {
    var total = 0;
    el.querySelectorAll('p').forEach(function (p) {
      total += (p.textContent || '').trim().length;
    });
    return total;
  };

  // The main part of the page: a marked article if there is a good one, otherwise
  // the block that holds the most paragraph text.
  var findMain = function () {
    var marked = document.querySelectorAll(
      'article, main, [role="main"], [itemprop="articleBody"], .post-content, .entry-content, .article-content, .article-body, #mw-content-text',
    );
    var best = null;
    var bestSize = 0;
    var sizes = [];
    marked.forEach(function (el) {
      var size = wordsIn(el);
      sizes.push([el, size]);
      if (size > bestSize) {
        best = el;
        bestSize = size;
      }
    });
    // A marked block inside the best one that holds nearly all of its text is the article itself,
    // without the page furniture around it.
    sizes.forEach(function (pair) {
      if (best && pair[0] !== best && best.contains(pair[0]) && pair[1] >= bestSize * 0.8) best = pair[0];
    });
    if (best && bestSize >= 400) return best;

    var scores = new Map();
    document.querySelectorAll('p').forEach(function (p) {
      var size = (p.textContent || '').trim().length;
      if (size < 60) return;
      var parent = p.parentElement;
      for (var depth = 0; parent && parent !== document.documentElement && depth < 3; depth++) {
        scores.set(parent, (scores.get(parent) || 0) + size / (depth + 1));
        parent = parent.parentElement;
      }
    });
    var winner = null;
    var top = 0;
    scores.forEach(function (score, el) {
      if (score > top && el !== document.body) {
        winner = el;
        top = score;
      }
    });
    return winner || best || document.body;
  };

  var title = (meta('meta[property="og:title"]') || document.title || '').replace(/\s+/g, ' ').trim();

  var main = cleanCopy(findMain());
  // The page's own headline is the note's title already; it is not repeated in the text.
  var headline = main.querySelector('h1');
  if (headline && title.indexOf((headline.textContent || '').trim()) === 0) headline.remove();

  var selectionHtml = '';
  var selection = window.getSelection();
  if (selection && selection.rangeCount && String(selection).trim().length > 0) {
    var holder = document.createElement('div');
    for (var i = 0; i < selection.rangeCount; i++) holder.appendChild(selection.getRangeAt(i).cloneContents());
    holder.querySelectorAll(JUNK).forEach(function (junk) {
      junk.remove();
    });
    fixAddresses(holder);
    selectionHtml = holder.innerHTML;
  }

  var time = document.querySelector('time[datetime]');
  return {
    title: title.slice(0, 300),
    url: location.href,
    site: (meta('meta[property="og:site_name"]') || location.hostname.replace(/^www\./, '')).slice(0, 120),
    author: (meta('meta[name="author"]') || meta('meta[property="article:author"]')).slice(0, 120),
    published: (meta('meta[property="article:published_time"]') || (time ? time.getAttribute('datetime') || '' : '')).slice(0, 40),
    description: (meta('meta[name="description"]') || meta('meta[property="og:description"]')).slice(0, 500),
    html: main.innerHTML.slice(0, MAX_HTML),
    selectionHtml: selectionHtml.slice(0, MAX_HTML),
  };
}
