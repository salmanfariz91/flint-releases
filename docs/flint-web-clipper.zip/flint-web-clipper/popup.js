/**
 * The panel that opens from the Flint button in the browser's toolbar.
 *
 * It reads the page (extract.js), asks the Flint app on this computer to turn it
 * into Markdown, shows the result so it can be edited, and hands the finished
 * note to Flint. Nothing is sent anywhere else: the only address contacted is
 * the Flint app on this computer.
 */
(function () {
  var FLINT = 'http://127.0.0.1:27631/clip/';
  var FOLDER_KEY = 'flint.folder';

  var $ = function (id) {
    return document.getElementById(id);
  };

  var tab = null;
  /** What extract.js found in the page. */
  var page = null;
  /** The note text for each choice, kept so edits survive switching between them. */
  var texts = { page: null, selection: null };
  var mode = 'page';
  var screenshot = '';

  /** Asks the Flint app. Fails with .offline when Flint cannot be reached, .denied when it said no. */
  async function ask(action, data) {
    var response;
    try {
      response = await fetch(FLINT + action, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data || {}),
      });
    } catch (e) {
      var offline = new Error('Flint cannot be reached.');
      offline.offline = true;
      throw offline;
    }
    var body = {};
    try {
      body = await response.json();
    } catch (e) {
      // An answer without a body is treated as empty.
    }
    if (!response.ok) {
      var failed = new Error(body.error || 'Flint could not do that.');
      failed.denied = !!body.denied;
      throw failed;
    }
    return body;
  }

  function showNotice(message, canRetry) {
    $('form').hidden = true;
    $('notice').hidden = false;
    $('notice-text').textContent = message;
    $('retry').hidden = !canRetry;
  }

  function setStatus(message, bad) {
    $('status').textContent = message;
    $('status').classList.toggle('bad', !!bad);
  }

  /** Shows the note text for "Selected text" or "Whole page", converting it the first time. */
  async function showText(which) {
    mode = which;
    if (texts[which] === null) {
      var html = which === 'selection' ? page.selectionHtml : page.html;
      if (html) {
        $('text').value = 'Preparing the text…';
        $('text').disabled = true;
        try {
          texts[which] = (await ask('convert', { html: html })).markdown || '';
        } finally {
          $('text').disabled = false;
        }
      } else {
        texts[which] = page.description || '';
      }
    }
    if (mode === which) $('text').value = texts[which];
  }

  function fillFolders(hello) {
    var select = $('folder');
    select.textContent = '';
    var none = document.createElement('option');
    none.value = '';
    none.textContent = 'No folder';
    select.appendChild(none);
    (hello.folders || []).forEach(function (folder) {
      var option = document.createElement('option');
      option.value = folder.id;
      option.textContent = folder.path;
      select.appendChild(option);
    });
    var remembered = null;
    try {
      remembered = localStorage.getItem(FOLDER_KEY);
    } catch (e) {
      // Remembering the folder is a convenience only.
    }
    var wanted = remembered !== null ? remembered : hello.defaultFolderId || '';
    var exists = [].some.call(select.options, function (o) {
      return o.value === wanted;
    });
    select.value = exists ? wanted : '';
  }

  async function start() {
    showNotice('Reading the page…');
    setStatus('');
    texts = { page: null, selection: null };
    screenshot = '';

    var tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    tab = tabs[0];
    if (!tab || !/^https?:\/\//i.test(tab.url || '')) {
      return showNotice('This page cannot be clipped.\nOpen a normal web page and click the Flint button again.');
    }

    var linkOnly = false;
    try {
      var results = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: flintExtractPage });
      page = results && results[0] && results[0].result;
    } catch (e) {
      page = null;
    }
    if (!page) {
      // Some pages (PDFs, the browser's own store) cannot be read; their title and link can still be saved.
      linkOnly = true;
      var host = '';
      try {
        host = new URL(tab.url).hostname.replace(/^www\./, '');
      } catch (e) {
        // Keep the host empty.
      }
      page = { title: tab.title || '', url: tab.url, site: host, author: '', published: '', description: '', html: '', selectionHtml: '' };
    }

    showNotice('Connecting to Flint…');
    var hello;
    try {
      hello = await ask('hello');
    } catch (e) {
      if (e.offline) {
        return showNotice(
          'Flint is not running on this computer.\n\nOpen Flint and click Try again. The clipper needs Flint 1.4.0 or newer, with "Web clipper" switched on in Settings.',
          true,
        );
      }
      if (e.denied) return showNotice('Flint was told not to allow this extension.\n\nClick Try again and choose Allow in Flint.', true);
      return showNotice(e.message, true);
    }

    $('title').value = page.title;
    $('source').textContent = (page.site ? page.site + ' · ' : '') + page.url;
    $('source').title = page.url;
    fillFolders(hello);

    var hasSelection = !!page.selectionHtml;
    $('what').hidden = !hasSelection;
    document.querySelector('input[name="what"][value="' + (hasSelection ? 'selection' : 'page') + '"]').checked = true;
    $('shot').checked = false;
    $('shot-preview').hidden = true;

    $('notice').hidden = true;
    $('form').hidden = false;
    $('add').disabled = false;
    if (linkOnly) setStatus('Only the title and link can be saved from this page.');
    try {
      await showText(hasSelection ? 'selection' : 'page');
    } catch (e) {
      $('text').value = '';
      setStatus(e.message, true);
    }
    $('title').focus();
  }

  $('retry').addEventListener('click', start);

  $('text').addEventListener('input', function () {
    texts[mode] = $('text').value;
  });

  document.querySelectorAll('input[name="what"]').forEach(function (radio) {
    radio.addEventListener('change', function () {
      if (!radio.checked) return;
      showText(radio.value).catch(function (e) {
        setStatus(e.message, true);
      });
    });
  });

  $('shot').addEventListener('change', async function () {
    var preview = $('shot-preview');
    if (!$('shot').checked) {
      preview.hidden = true;
      return;
    }
    try {
      if (!screenshot) screenshot = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
      preview.src = screenshot;
      preview.hidden = false;
      setStatus('');
    } catch (e) {
      $('shot').checked = false;
      preview.hidden = true;
      setStatus('A screenshot cannot be taken of this page.', true);
    }
  });

  $('form').addEventListener('submit', async function (event) {
    event.preventDefault();
    $('add').disabled = true;
    setStatus('Saving…');
    var folderId = $('folder').value;
    try {
      await ask('add', {
        title: $('title').value,
        markdown: $('text').value,
        url: page.url,
        site: page.site,
        author: page.author,
        tags: $('tags')
          .value.split(/[,\s]+/)
          .filter(Boolean),
        folderId: folderId,
        screenshot: $('shot').checked ? screenshot : '',
      });
    } catch (e) {
      $('add').disabled = false;
      return setStatus(e.offline ? 'Flint is not running. Open Flint and try again.' : e.message, true);
    }
    try {
      localStorage.setItem(FOLDER_KEY, folderId);
    } catch (e) {
      // Remembering the folder is a convenience only.
    }
    setStatus('Saved to Flint');
    setTimeout(function () {
      window.close();
    }, 900);
  });

  start().catch(function (e) {
    showNotice(e && e.message ? e.message : 'Something went wrong. Close this panel and try again.', true);
  });
})();
